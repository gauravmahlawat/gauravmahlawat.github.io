
ABOUT STARK
-----------

This theme is provided for demonstration purposes; it uses Drupal's
default HTML markup and CSS styles. It can be used as a troubleshooting tool to
determine whether module-related CSS and JavaScript are interfering with a more
complex theme, and can be used by designers interested in studying Drupal's
default markup without the interference of changes commonly made by more
complex themes.

To avoid obscuring CSS added to the page by Drupal or a contrib module, this theme itself has no styling.
